
PLUGIN.name = "Cigarettes"
PLUGIN.description = "Adds smokeable cigarettes. Smoke my ciggies, smoke my cigarettes."
PLUGIN.author = "j o e"
