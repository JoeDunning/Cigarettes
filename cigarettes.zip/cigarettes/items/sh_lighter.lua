ITEM.name = "Lighter"
ITEM.description = "A very scuffed flip lighter, has a port at the bottom for lighter fluid still intact."
ITEM.model = "models/kek1ch/dev_lighter.mdl"
ITEM.width = 1
ITEM.height = 1